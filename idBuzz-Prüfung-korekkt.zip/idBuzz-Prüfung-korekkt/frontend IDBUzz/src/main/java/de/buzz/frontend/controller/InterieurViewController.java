package de.buzz.frontend.controller;

import de.buzz.frontend.model.IdBuzz;
import de.buzz.frontend.model.Seat;
import de.buzz.frontend.model.SteerWheel;
import de.buzz.frontend.view.ExtraView;
import de.buzz.frontend.view.InterieurView;
import de.buzz.frontend.view.MainView;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import lombok.Data;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Sarah Klein
 */
@Data
public class InterieurViewController {
    private InterieurView interieurView;
    private MainView mainView;
    private ExtraView extraView;
    private List<Seat> seatlist = new ArrayList<>();
    private List<SteerWheel> steeringwheelList = new ArrayList<>();
    private ToggleGroup toggleGroupSeat;
    private ToggleGroup toggleGroupSteeringWheel;
    private Map<RadioButton, Seat> seatMap = new HashMap<>();
    private Map<RadioButton, SteerWheel> steeringWheelMap = new HashMap<>();
    private Map<Long, Seat> seatMapForDTOConversion = new HashMap<>();
    private Map<Long, SteerWheel> steeringWheelMapForDTOConversion = new HashMap<>();

    private IntegerProperty currentPriceSeat;
    private IntegerProperty currentPriceSteeringWheel;
    private IdBuzz idbuzz;


    public InterieurViewController(InterieurView interieurView, MainView mainView, ExtraView extraView, IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.interieurView = interieurView;
        this.mainView = mainView;
        this.extraView = extraView;
        this.currentPriceSeat = new SimpleIntegerProperty(0);
        this.currentPriceSteeringWheel = new SimpleIntegerProperty(0);
        fillSeatBoxes(getAllSeats());
        fillSteeringwheelBoxes(getAllSteerwheel());
    }


    public void changeCenterWhenToggleIsSelected() {

        if (this.toggleGroupSeat.getSelectedToggle() == null || this.toggleGroupSteeringWheel.getSelectedToggle() == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Option treffen");
            alert.setContentText("es muss eine Option angewählt sein");
            alert.showAndWait();
        } else {
            this.mainView.setCenter(this.extraView);
            takeSelectedRadiobuttonAndSetCorrespondingInterieurInIdBuzz();
        }

    }

    public void fillSeatBoxes(List<Seat> seats) {
        this.toggleGroupSeat = new ToggleGroup();
        for (Seat seat : seats) {
            RadioButton seatRadiobutton = new RadioButton("Sitz :" + seat.getSeatColor() + " ," + seat.getSeatMaterial() + " ," + seat.getSeatPattern() + " Preis: " + seat.getSeatPriceInCent());
            this.interieurView.getSeatBox().getChildren().addAll(seatRadiobutton);
            this.seatMap.put(seatRadiobutton, seat);
            this.seatMapForDTOConversion.put(seat.getSeatId(), seat);
            seatRadiobutton.setToggleGroup(this.toggleGroupSeat);
            this.toggleGroupSeat.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {

                @Override
                public void changed(ObservableValue<? extends Toggle> ov,
                                    Toggle old_toggle, Toggle new_toggle) {
                    InterieurViewController.this.currentPriceSeat.set(InterieurViewController.this.seatMap.get(new_toggle).getSeatPriceInCent());
                }
            });


        }
    }

    public void fillSteeringwheelBoxes(List<SteerWheel> steeringwheels) {
        this.toggleGroupSteeringWheel = new ToggleGroup();
        for (SteerWheel steeringwheel : steeringwheels) {
            RadioButton radioButtonSteeringWheel = new RadioButton("Lenkrad: " + steeringwheel.getSteerWheelColor() + ", " + steeringwheel.getSteerWheelMaterial() + " Preis: " + steeringwheel.getSteerWheelPriceInCent());
            this.interieurView.getSteeringwheelBox().getChildren().addAll(radioButtonSteeringWheel);
            this.steeringWheelMap.put(radioButtonSteeringWheel, steeringwheel);
            this.steeringWheelMapForDTOConversion.put(steeringwheel.getSteerWheelId(), steeringwheel);
            radioButtonSteeringWheel.setToggleGroup(this.toggleGroupSteeringWheel);
            this.toggleGroupSteeringWheel.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                @Override
                public void changed(ObservableValue<? extends Toggle> ov,
                                    Toggle old_toggle, Toggle new_toggle) {
                    InterieurViewController.this.currentPriceSteeringWheel.set(InterieurViewController.this.steeringWheelMap.get(new_toggle).getSteerWheelPriceInCent());
                }
            });
        }
    }

    public void takeSelectedRadiobuttonAndSetCorrespondingInterieurInIdBuzz() {
        RadioButton rbSeat = (RadioButton) this.toggleGroupSeat.getSelectedToggle();
        this.idbuzz.getInterieur().setSeat(this.seatMap.get(rbSeat));
        RadioButton rbSteeringWheel = (RadioButton) this.toggleGroupSteeringWheel.getSelectedToggle();
        this.idbuzz.getInterieur().setSteeringwheel(this.steeringWheelMap.get(rbSteeringWheel));

    }

    public List<Seat> getAllSeats() {
        WebRequest<List<Seat>> webRequestList = new WebRequest<>("/seats");
        try {
            this.seatlist.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, Seat.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.seatlist;
    }

    public List<SteerWheel> getAllSteerwheel() {
        WebRequest<List<SteerWheel>> webRequestList = new WebRequest<>("/steerWheels");
        try {
            this.steeringwheelList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, SteerWheel.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.steeringwheelList;
    }
}


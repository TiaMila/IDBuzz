package de.buzz.frontend.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 * edited by Andy Jordan
 */
@Data
public class StartView extends BorderPane {

    private Label helloLabel;
    private Button editButton;
    private Button startConfigButton;
    private Button homeButton;
    private TextField placeholder;
    private NumberOnlyTextField idTextField;
    private HBox editBox;
    private HBox configurationBox;
    private HBox labelBox;
    private VBox buttonBox;
    private VBox navBox;


    public StartView() {
        this.initializeTop();
        this.initializeCenter();
        this.setCenter(this.buttonBox);
        this.setTop(this.labelBox);
    }

    public void initializeTop() {
        this.labelBox = new HBox();
        this.helloLabel = new Label("Herzlich Willkommen beim Volkswagen ID.Buzz-Konfigurator");
        this.labelBox.getChildren().add(this.helloLabel);
        this.labelBox.setAlignment(Pos.TOP_CENTER);

    }

    public void initializeCenter() {
        this.buttonBox = new VBox();
        this.editBox = new HBox();
        this.configurationBox = new HBox();
        this.placeholder = new TextField();
        this.placeholder.setVisible(false);
        this.idTextField = new NumberOnlyTextField();
        this.idTextField.setPromptText("id eingeben");
        this.editButton = new Button("Konfiguration bearbeiten");
        this.startConfigButton = new Button("Neue Konfiguration");
        this.editBox.getChildren().addAll(this.idTextField, this.editButton);
        this.editBox.setSpacing(30);
        this.editBox.setAlignment(Pos.CENTER);
        this.configurationBox.getChildren().addAll(this.placeholder, this.startConfigButton);
        this.configurationBox.setAlignment(Pos.CENTER);
        this.buttonBox.getChildren().addAll(this.configurationBox, this.editBox);
        this.buttonBox.setAlignment(Pos.CENTER);
    }


}

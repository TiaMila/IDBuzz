package de.buzz.frontend.controller;


import de.buzz.frontend.model.CarModel;
import de.buzz.frontend.model.IdBuzz;
import de.buzz.frontend.view.EngineView;
import de.buzz.frontend.view.MainView;
import de.buzz.frontend.view.ModelView;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import lombok.Data;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;



import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author Sarah Klein
 */
@Data
public class ModelViewController {
    private List<IdBuzz> dummyBuzzes = new ArrayList<>();
    private ModelView modelView;
    private MainView mainView;
    private EngineView engineView;
    private Map<RadioButton, CarModel> modelMap = new HashMap<>();
    private Map<Long, CarModel> modelMapForDTOConversion = new HashMap<>();
    private IntegerProperty currentPrice;
    private ToggleGroup toggleGroup;
    private List<CarModel> modelList = new ArrayList<>();
    private IdBuzz idbuzz;


    public ModelViewController(ModelView modelView, MainView mainview, EngineView engineView, IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.modelView = modelView;
        this.mainView = mainview;
        this.engineView = engineView;
        this.currentPrice = new SimpleIntegerProperty(0);
        fillModelBoxes(getAllModels());
        testMethode();
    }


    public void changeCenterWhenToggleIsSelected() {
        if (this.toggleGroup.getSelectedToggle() == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Option treffen");
            alert.setContentText("es muss eine Option angewählt sein");
            alert.showAndWait();
        } else {
            this.mainView.setCenter(this.engineView);
            takeSelectedRadiobuttonAndSetCorrespondingModelInIdBuzz();
        }
    }

    public void fillModelBoxes(List<CarModel> models) {
        this.toggleGroup = new ToggleGroup();
        for (CarModel model : models) {
            RadioButton radioButton = new RadioButton("Model : " + model.getCarModelName() + " Preis: " + model.getCarModelPriceInCent());
            this.modelMap.put(radioButton, model);
            this.modelMapForDTOConversion.put(model.getCarModelId(), model);
            this.modelView.getRadioBox().getChildren().addAll(radioButton);


            addToggleGroupChangeListener(radioButton, this.toggleGroup);


        }
    }

    private void addToggleGroupChangeListener(RadioButton radioButton, ToggleGroup toggleGroup) {
        radioButton.setToggleGroup(toggleGroup);
        toggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> ov,
                                Toggle old_toggle, Toggle new_toggle) {
                ModelViewController.this.currentPrice.set(ModelViewController.this.modelMap.get(new_toggle).getCarModelPriceInCent());
            }
        });
    }


    public void takeSelectedRadiobuttonAndSetCorrespondingModelInIdBuzz() {
        RadioButton rb = (RadioButton) this.toggleGroup.getSelectedToggle();
        this.idbuzz.setModel(this.modelMap.get(rb));
    }

    public List<CarModel> getAllModels() {
        WebRequest<List<CarModel>> webRequestList = new WebRequest<>("/carModels");
        try {
            this.modelList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, CarModel.class));
        } catch (IOException e) {
            e.printStackTrace();

        }
        return this.modelList;

    }

    private void testMethode() {

        RestTemplate rest = new RestTemplate();
        String url = "http://localhost:8090/carModels";
        ResponseEntity<List> response = rest.getForEntity(url, List.class);
        List json = response.getBody();
        System.out.println(json);
    }

}

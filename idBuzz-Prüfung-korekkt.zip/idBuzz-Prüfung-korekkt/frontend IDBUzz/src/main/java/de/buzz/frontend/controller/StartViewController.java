package de.buzz.frontend.controller;

import de.buzz.frontend.view.MainView;
import de.buzz.frontend.view.StartView;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import lombok.Data;

import de.buzz.frontend.model.*;


import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Sarah Klein
 */
@Data
public class StartViewController {
    private StartView startView;
    private MainView mainView;
    private MainViewController mainViewController;
    public static String configurationIDTextfield = "";
    public static CarModel model1;
    private Map<Integer, CarModel> carModelMapForConversion = new HashMap<>();
    private IdBuzz idbuzz = new IdBuzz();
    private BuzzDTO buzzDTO = new BuzzDTO();

    public StartViewController(StartView startView) {
        this.startView = startView;
        this.handleStartConfigButton();
        handleEditConfigButton();
    }

    public void handleStartConfigButton() {
        this.startView.getStartConfigButton().setOnAction(e -> {
            this.mainView = new MainView();

            this.mainViewController = new MainViewController(this.mainView);

            this.startView.getScene().setRoot(this.mainView);
            this.mainView.setCenter(this.mainViewController.getModelView());
            this.mainView.getBackButton().setVisible(false);


        });
    }


    public void handleEditConfigButton() {
        this.startView.getEditButton().setOnAction(e -> {
            configurationIDTextfield = this.startView.getIdTextField().getText();
            try {
                this.buzzDTO = getBuzzById(Integer.parseInt(configurationIDTextfield));

                System.out.println(this.buzzDTO);
            } catch (IOException ex) {
                ex.printStackTrace();
            }


            if (this.buzzDTO.getBuzzConfigurationCode() != 0) {
                this.mainView = new MainView();
                this.mainViewController = new MainViewController(this.mainView, this.buzzDTO);
                this.startView.getScene().setRoot(this.mainView);
                this.mainView.setCenter(this.mainViewController.getModelView());
                this.mainView.getBackButton().setVisible(false);
                this.idbuzz = convertBuzzDTOToIdBuzzz(this.buzzDTO);
                this.idbuzz.setConfigurationID(this.buzzDTO.getBuzzConfigurationCode());
                readConfigurationByID();

            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Wrong ID");
                alert.setContentText("id existiert nicht");
                alert.showAndWait();
            }
        });


    }

    public void readConfigurationByID() {

        readModelViewConfiguration();
        readEngineViewConfiguration();
        readExterieurViewConfiguration();
        readInterieurConfiguration();
        readExtrasConfiguration();
    }

    private void readExtrasConfiguration() {

        List<Extra> extras = this.idbuzz.getExtras();
        for (Extra extra : extras) {
            String extraString = extra.getExtraName();
            Map<RadioButton, Extra> extramap = this.mainViewController.getExtraViewController().getExtrasMap();
            for (RadioButton rb : extramap.keySet()) {
                if (rb.getText().contains(extraString)) {
                    rb.setSelected(true);
                    this.mainViewController.getExtraViewController().getSelectedRadioButtonsList().add(rb);

                }
            }
        }


    }


    private void readInterieurConfiguration() {

        String nameSeat = this.idbuzz.getInterieur().getSeat().getSeatColor();
        String nameSteeringWheel = this.idbuzz.getInterieur().getSteeringwheel().getSteerWheelColor();
        Map<RadioButton, Seat> seat = this.mainViewController.getInterieurViewController().getSeatMap();
        Map<RadioButton, SteerWheel> steeringWheel = this.mainViewController.getInterieurViewController().getSteeringWheelMap();


        for (RadioButton rb : seat.keySet()) {
            if (rb.getText().contains(nameSeat)) {
                rb.setSelected(true);
            }
        }
        for (RadioButton rb : steeringWheel.keySet()) {
            if (rb.getText().contains(nameSteeringWheel)) {
                rb.setSelected(true);

            }
        }
    }


    private void readExterieurViewConfiguration() {
        String nameRim = this.idbuzz.getExterieur().getRim().getRimSpecification();
        String nameTyre = this.idbuzz.getExterieur().getTyre().getTyreSpecification();
        String nameMirror = this.idbuzz.getExterieur().getMirror().getMirrorShape();
        String nameCarPaint = this.idbuzz.getExterieur().getColor().getCarPaintName();

        Map<RadioButton, Rim> mapRim = this.mainViewController.getExterieurViewController().getRimMap();
        Map<RadioButton, Tyre> mapTyre = this.mainViewController.getExterieurViewController().getTyreMap();
        Map<RadioButton, Mirror> mapMirror = this.mainViewController.getExterieurViewController().getMirrorMap();
        Map<RadioButton, CarPaint> mapCarPaint = this.mainViewController.getExterieurViewController().getCarPaintMap();

        for (RadioButton rbRim : mapRim.keySet()) {
            if (rbRim.getText().contains(nameRim)) {
                rbRim.setSelected(true);
            }
        }

        for (RadioButton rbTyre : mapTyre.keySet()) {
            if (rbTyre.getText().contains(nameTyre)) {
                rbTyre.setSelected(true);
            }
        }
        for (RadioButton rbMirror : mapMirror.keySet()) {
            if (rbMirror.getText().contains(nameMirror)) {
                rbMirror.setSelected(true);
            }
        }
        for (RadioButton rbCarPaint : mapCarPaint.keySet()) {
            if (rbCarPaint.getText().contains(nameCarPaint)) {
                rbCarPaint.setSelected(true);
            }
        }

    }

    private void readEngineViewConfiguration() {

        String name = this.idbuzz.getEngine().getEnginesSpecification();
        Engine engineModel = this.mainViewController.getEngineViewController().getEngineMapForDTOConversion().get(this.buzzDTO.getEngine());
        this.idbuzz.setEngine(engineModel);

        Map<RadioButton, Engine> map = this.mainViewController.getEngineViewController().getEngineMap();
        for (RadioButton rb : map.keySet()) {
            if (rb.getText().contains(name)) {
                rb.setSelected(true);
            }
        }
    }


    private void readModelViewConfiguration() {
        String name = this.idbuzz.getModel().getCarModelName();
        CarModel carModel = this.mainViewController.getModelViewController().getModelMapForDTOConversion().get(this.buzzDTO.getCarModel());
        this.idbuzz.setModel(carModel);

        Map<RadioButton, CarModel> map = this.mainViewController.getModelViewController().getModelMap();
        for (RadioButton rb : map.keySet()) {
            if (rb.getText().contains(name)) {
                rb.setSelected(true);
                rb.selectedProperty().set(true);
            }
        }
    }

    public BuzzDTO getBuzzById(int id) throws IOException {
        WebRequest<BuzzDTO> webRequestList = new WebRequest<>("/api/buzz?id=" + id);
        return webRequestList.doRequest("", WebRequest.RequestType.GET, BuzzDTO.class);
    }

    public IdBuzz convertBuzzDTOToIdBuzzz(BuzzDTO buzzDTO) {
        this.idbuzz.setConfigurationID(buzzDTO.getBuzzConfigurationCode());
        this.idbuzz.setModel(this.mainViewController.getModelViewController().getModelMapForDTOConversion().get(buzzDTO.getCarModel()));
        this.idbuzz.setEngine(this.mainViewController.getEngineViewController().getEngineMapForDTOConversion().get(buzzDTO.getEngine()));
        this.idbuzz.setExterieur(new Exterieur(new CarPaint("DeepBlue", "metalic", 1000, 1), this.mainViewController.getExterieurViewController().getRimMapForDTOConversion().get(buzzDTO.getRim()), this.mainViewController.getExterieurViewController().getTyreMapForDTOConversion().get(buzzDTO.getTyre()), this.mainViewController.getExterieurViewController().getMirrorMapForDTOConversion().get(buzzDTO.getMirror())));
        this.idbuzz.setInterieur(new Interieur(this.mainViewController.getInterieurViewController().getSeatMapForDTOConversion().get(buzzDTO.getSeat()), this.mainViewController.getInterieurViewController().getSteeringWheelMapForDTOConversion().get(buzzDTO.getSteerWheel())));

        //Methoden referenz von jedem elemt wird die id genommen Extra::getId = (e -> e.getId)
        this.idbuzz.setExtras(buzzDTO.getExtras().stream().map(e -> this.mainViewController.getExtraViewController().getExtrasForDTOConversion().get(e)).collect(Collectors.toList()));
        return this.idbuzz;
    }


    public StartView getView() {
        return this.startView;
    }

}

package de.buzz.frontend.view;

import javafx.scene.control.TextField;

/**
 * @Autor : Andy Jordan (SE-A/31)
 */
public class NumberOnlyTextField extends TextField {
    @Override
    public void replaceText(int start, int end, String text) {
        if (this.isNumber(text)) {
            super.replaceText(start, end, text);
        }
    }

    @Override
    public void replaceSelection(String text) {
        if (this.isNumber(text)) {
            super.replaceSelection(text);
        }
    }

    private boolean isNumber(String text) {
        return text.matches("[0-9]*");
    }

}

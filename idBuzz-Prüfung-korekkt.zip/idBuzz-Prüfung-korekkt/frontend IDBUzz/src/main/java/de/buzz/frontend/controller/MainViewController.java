package de.buzz.frontend.controller;

import de.buzz.frontend.model.*;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.Node;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import lombok.Data;


import de.buzz.frontend.view.*;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Sarah Klein
 */
@Data
public class MainViewController {

    private MainView mainView;
    private StartView startView;
    private ModelViewController modelViewController;
    private EngineView engineView;
    private ExterieurView exterieurView;
    private ExtraView extraView;
    private FinishView finishView;
    private InterieurView interieurView;
    private ModelView modelView;
    private StartViewController startViewController;
    private EngineViewController engineViewController;
    private ExterieurViewController exterieurViewController;
    private ExtraViewController extraViewController;
    private FinishViewController finishViewController;
    private InterieurViewController interieurViewController;
    private Map<Integer, Node> viewMap;
    private IntegerProperty stepForewardProperty;
    private int currentCenterIndex = 1;
    public IdBuzz idbuzz = new IdBuzz(0, new CarModel(), new Exterieur(), new Interieur(), new Engine(), new ArrayList<Extra>());
    private String configurationID;
    private IntegerProperty currentPrice = new SimpleIntegerProperty(0);
    private BuzzDTO buzzDTO;


    public MainViewController(MainView mainview, BuzzDTO buzzDTO) {
        this.mainView = mainview;
        initializeViews();
        initializeControllers();
        handleForwardButton();
        handleBackButton();
        this.idbuzz.setConfigurationID(buzzDTO.getBuzzConfigurationCode());

        this.currentPrice.bind(Bindings.createIntegerBinding(() -> {
            return this.modelViewController.getCurrentPrice().get() + this.engineViewController.getCurrentPrice().get() + this.exterieurViewController.getCurrentPriceRim().get() + this.exterieurViewController.getCurrentPriceTyre().get() + this.exterieurViewController.getCurrentPriceMirror().get() + this.exterieurViewController.getCurrentPriceCarPaint().get() + this.interieurViewController.getCurrentPriceSeat().get() + this.interieurViewController.getCurrentPriceSteeringWheel().get() + this.extraViewController.getCurrentPriceExtra().get();
        }, this.modelViewController.getCurrentPrice(), this.engineViewController.getCurrentPrice(), this.exterieurViewController.getCurrentPriceRim(), this.exterieurViewController.getCurrentPriceTyre(), this.exterieurViewController.getCurrentPriceMirror(), this.exterieurViewController.getCurrentPriceCarPaint(), this.interieurViewController.getCurrentPriceSeat(), this.interieurViewController.getCurrentPriceSteeringWheel(), this.extraViewController.getCurrentPriceExtra()));
        this.mainView.getPriceLabel().textProperty().bind(this.currentPrice.asString());
    }

    public MainViewController(MainView mainview) {
        this.mainView = mainview;
        initializeViews();
        initializeControllers();
        handleForwardButton();
        handleBackButton();

        this.currentPrice.bind(Bindings.createIntegerBinding(() -> {
            return this.modelViewController.getCurrentPrice().get() + this.engineViewController.getCurrentPrice().get() + this.exterieurViewController.getCurrentPriceRim().get() + this.exterieurViewController.getCurrentPriceTyre().get() + this.exterieurViewController.getCurrentPriceMirror().get() + this.exterieurViewController.getCurrentPriceCarPaint().get() + this.interieurViewController.getCurrentPriceSeat().get() + this.interieurViewController.getCurrentPriceSteeringWheel().get() + this.extraViewController.getCurrentPriceExtra().get();
        }, this.modelViewController.getCurrentPrice(), this.engineViewController.getCurrentPrice(), this.exterieurViewController.getCurrentPriceRim(), this.exterieurViewController.getCurrentPriceTyre(), this.exterieurViewController.getCurrentPriceMirror(), this.exterieurViewController.getCurrentPriceCarPaint(), this.interieurViewController.getCurrentPriceSeat(), this.interieurViewController.getCurrentPriceSteeringWheel(), this.extraViewController.getCurrentPriceExtra()));
        this.mainView.getPriceLabel().textProperty().bind(this.currentPrice.asString());
    }

    public void initializeViews() {
        this.viewMap = new HashMap<>();
        this.modelView = new ModelView();
        this.engineView = new EngineView();
        this.exterieurView = new ExterieurView();
        this.extraView = new ExtraView();
        this.finishView = new FinishView();
        this.interieurView = new InterieurView();
        this.viewMap.put(1, this.modelView);
        this.viewMap.put(2, this.engineView);
        this.viewMap.put(3, this.exterieurView);
        this.viewMap.put(4, this.interieurView);
        this.viewMap.put(5, this.extraView);
        this.viewMap.put(6, this.finishView);
    }

    private void initializeControllers() {
        this.modelViewController = new ModelViewController(this.modelView, this.mainView, this.engineView, this.idbuzz);
        this.engineViewController = new EngineViewController(this.engineView, this.mainView, this.exterieurView, this.idbuzz);
        this.exterieurViewController = new ExterieurViewController(this.exterieurView, this.mainView, this.interieurView, this.idbuzz);
        this.interieurViewController = new InterieurViewController(this.interieurView, this.mainView, this.extraView, this.idbuzz);
        this.extraViewController = new ExtraViewController(this.extraView, this.mainView, this.idbuzz);
        this.finishViewController = new FinishViewController(this.finishView, this.mainView, this.idbuzz);

    }

    public void handleForwardButton() {
        this.mainView.getForewardButton().setOnAction(e -> {
            try {
                changeSceneForward();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }

    public void handleBackButton() {
        this.mainView.getBackButton().setOnAction(e -> {
            changeSceneBack();
        });
    }

    private void changeSceneForward() throws IOException {
        if (this.mainView.getCenter() == this.modelView) {
            this.modelViewController.changeCenterWhenToggleIsSelected();
            this.mainView.getBackButton().setVisible(true);


        } else if (this.mainView.getCenter() == this.engineView) {
            this.engineViewController.changeCenterWhenToggleIsSelected();
            handleButtonChoosingOptionsExterieur();

        } else if (this.mainView.getCenter() == this.exterieurView) {
            this.exterieurViewController.changeCenterWhenToggleIsSelected();
            handleButtonChoosingOptionsInterieur();

        } else if (this.mainView.getCenter() == this.interieurView) {
            this.interieurViewController.changeCenterWhenToggleIsSelected();

        } else if (this.mainView.getCenter() == this.extraView) {
            this.extraViewController.takeSelectedRadiobuttonAndSetCorrespondingExtraInIdBuzz();
            this.mainView.setCenter(this.finishView);
            this.mainView.getForewardButton().setVisible(false);


            System.out.println(this.idbuzz.toString());
            if (this.idbuzz.getConfigurationID() == 0) {
                this.buzzDTO = convertIdBuzzToBuzzDTO(this.idbuzz);
                System.out.println(this.buzzDTO);
                String id = String.valueOf(doPostRequest(this.buzzDTO));
                this.finishView.getIdLabel().setText("This is your id: " + id);


            } else {
                this.buzzDTO = convertIdBuzzToBuzzDTO(this.idbuzz);
                doPutRequest(this.buzzDTO);
            }

        } else {
            System.out.println("Scenenn wechsel geht nicht ");
        }


    }

    private void changeSceneBack() {
        if (this.mainView.getCenter() == this.engineView) {
            this.mainView.setCenter(this.modelView);
            this.mainView.getBackButton().setVisible(false);
        } else if (this.mainView.getCenter() == this.exterieurView) {
            this.mainView.setCenter(this.engineView);
        } else if (this.mainView.getCenter() == this.interieurView) {
            this.mainView.setCenter(this.exterieurView);
        } else if (this.mainView.getCenter() == this.extraView) {
            this.mainView.setCenter(this.interieurView);
        } else if (this.mainView.getCenter() == this.finishView) {
            this.mainView.setCenter(this.extraView);
            this.mainView.getForewardButton().setVisible(true);
        } else {
            System.out.println("Scenenn wechsel geht nicht ");
        }
    }


    public void handleButtonChoosingOptionsExterieur() {
        String engineName = this.idbuzz.getEngine().getEnginesSpecification();
        List<Toggle> rbRimToggle = this.exterieurViewController.getToggleGroupRim().getToggles();
        for (Toggle toggle : rbRimToggle) {
            RadioButton b = (RadioButton) toggle;
            String restriction = this.exterieurViewController.getRimMap().get(b).getRimRestriction();

            if (engineName.equals("Eco-II")) {
                if (restriction.equals("Eco-II")) {
                    b.setDisable(true);
                }
            }
        }
    }


    public void handleButtonChoosingOptionsInterieur() {
        String name = this.idbuzz.getModel().getCarModelName();
        List<Toggle> rbSteeringwheel = this.interieurViewController.getToggleGroupSteeringWheel().getToggles();
        for (Toggle toggle1 : rbSteeringwheel) {
            RadioButton r = (RadioButton) toggle1;
            String restriction = this.interieurViewController.getSteeringWheelMap().get(r).getSteerWheelRestriction();
            if (name.equals("IDBUZZElegance")) {
                if (restriction.equals("ID.Buzz Elegance")) {
                    r.setDisable(true);
                }
            }
        }
    }


    public Long doPostRequest(BuzzDTO buzz) throws IOException {
        WebRequest<BuzzDTO> webRequest = new WebRequest<>("/idbuzzs");
        return webRequest.doRequest(buzz, WebRequest.RequestType.POST, Long.class);
    }

    public void doPutRequest(BuzzDTO buzz) throws IOException {
        WebRequest<BuzzDTO> webRequest = new WebRequest<>("/buzz?id=" + buzz.getBuzzConfigurationCode());
        webRequest.doRequest(buzz, WebRequest.RequestType.PUT, Object.class);
    }


    public BuzzDTO convertIdBuzzToBuzzDTO(IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.buzzDTO = new BuzzDTO();
        this.buzzDTO.setBuzzConfigurationCode(idbuzz.getConfigurationID());
        this.buzzDTO.setCarModel(idbuzz.getModel().getCarModelId());
        this.buzzDTO.setEngine(idbuzz.getEngine().getEngineId());
        this.buzzDTO.setRim(idbuzz.getExterieur().getRim().getRimId());
        this.buzzDTO.setTyre(idbuzz.getExterieur().getTyre().getTyreId());
        this.buzzDTO.setMirror(idbuzz.getExterieur().getMirror().getMirrorId());
        this.buzzDTO.setCarPaint(idbuzz.getExterieur().getColor().getCarPaintId());
        this.buzzDTO.setSeat(idbuzz.getInterieur().getSeat().getSeatId());
        this.buzzDTO.setSteerWheel(idbuzz.getInterieur().getSteeringwheel().getSteerWheelId());
        this.buzzDTO.setTrim(1);
//Methoden referenz von jedem elemt wird die id genommen Extra::getId = (e -> e.getId)
        this.buzzDTO.setExtras(idbuzz.getExtras().stream().map(Extra::getExtraId).collect(Collectors.toList()));
        return this.buzzDTO;
    }
}



package de.buzz.frontend.controller;

import de.buzz.frontend.model.*;
import de.buzz.frontend.view.ExterieurView;
import de.buzz.frontend.view.InterieurView;
import de.buzz.frontend.view.MainView;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import lombok.Data;



import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Sarah Klein
 */
@Data
public class ExterieurViewController {
    private ExterieurView exterieurView;
    private MainView mainView;
    private InterieurView interieurView;
    private List<Tyre> tyreList = new ArrayList<>();
    private List<Rim> rimList = new ArrayList<>();
    private List<Mirror> mirrorlist = new ArrayList<>();
    private List<CarPaint> carpaintList = new ArrayList<>();
    private ToggleGroup toggleGroupRim;
    private ToggleGroup toggleGroupTyre;
    private ToggleGroup toggleGroupMirror;
    private ToggleGroup toggleGroupCarPaint;
    private Map<RadioButton, Rim> rimMap = new HashMap<>();
    private Map<RadioButton, Tyre> tyreMap = new HashMap<>();
    private Map<RadioButton, Mirror> mirrorMap = new HashMap<>();
    private Map<RadioButton, CarPaint> carPaintMap = new HashMap<>();
    private Map<Long, Rim> rimMapForDTOConversion = new HashMap<>();
    private Map<Long, Tyre> tyreMapForDTOConversion = new HashMap<>();
    private Map<Long, Mirror> mirrorMapForDTOConversion = new HashMap<>();
    private Map<Long, CarPaint> carPaintMapForDTOConversion = new HashMap<>();
    private IntegerProperty currentPriceRim;
    private IntegerProperty currentPriceTyre;
    private IntegerProperty currentPriceMirror;
    private IntegerProperty currentPriceCarPaint;
    private IdBuzz idbuzz;

    public ExterieurViewController(ExterieurView exterieurView, MainView mainView, InterieurView interieurView, IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.exterieurView = exterieurView;
        this.mainView = mainView;
        this.interieurView = interieurView;
        this.currentPriceRim = new SimpleIntegerProperty(0);
        this.currentPriceTyre = new SimpleIntegerProperty(0);
        this.currentPriceMirror = new SimpleIntegerProperty(0);
        this.currentPriceCarPaint = new SimpleIntegerProperty(0);
        fillRimBoxes(getAllRims());
        fillTyreBoxes(getAllTyres());
        fillCarMirrorBoxes(getAllMirrors());
        fillCarPaintBoxes(getAllCarPaints());
        takeSelectedRadiobuttonAndSetCorrespondingExterieurInIdBuzz();
    }


    public void changeCenterWhenToggleIsSelected() {
        if (this.toggleGroupTyre.getSelectedToggle() == null || this.toggleGroupRim.getSelectedToggle() == null || this.toggleGroupTyre.getSelectedToggle() == null || this.toggleGroupCarPaint.getSelectedToggle() == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Option treffen");
            alert.setContentText("es muss eine Option angewählt sein");
            alert.showAndWait();
        } else {
            this.mainView.setCenter(this.interieurView);
            takeSelectedRadiobuttonAndSetCorrespondingExterieurInIdBuzz();
        }

    }


    public void fillTyreBoxes(List<Tyre> tyres) {
        this.toggleGroupTyre = new ToggleGroup();
        for (Tyre tyre : tyres) {
            RadioButton radioButton = new RadioButton("Reifen: " + tyre.getTyreSpecification() + "Preis: " + tyre.getTyrePriceInCent());
            this.exterieurView.getTyreBox().getChildren().addAll(radioButton);
            this.tyreMap.put(radioButton, tyre);
            this.tyreMapForDTOConversion.put(tyre.getTyreId(), tyre);
            radioButton.setToggleGroup(this.toggleGroupTyre);
            this.toggleGroupTyre.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                @Override
                public void changed(ObservableValue<? extends Toggle> ov,
                                    Toggle old_toggle, Toggle new_toggle) {
                    ExterieurViewController.this.currentPriceTyre.set(ExterieurViewController.this.tyreMap.get(new_toggle).getTyrePriceInCent());
                }
            });
        }
    }

    public void fillRimBoxes(List<Rim> rims) {
        this.toggleGroupRim = new ToggleGroup();
        for (Rim rim : rims) {
            RadioButton radioButton = new RadioButton("Felge: " + rim.getRimSpecification() + " Pris: " + rim.getRimPriceInCent());
            this.exterieurView.getRimBox().getChildren().addAll(radioButton);
            this.rimMap.put(radioButton, rim);
            this.rimMapForDTOConversion.put(rim.getRimId(), rim);
            radioButton.setToggleGroup(this.toggleGroupRim);
            this.toggleGroupRim.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                @Override
                public void changed(ObservableValue<? extends Toggle> ov,
                                    Toggle old_toggle, Toggle new_toggle) {
                    ExterieurViewController.this.currentPriceRim.set(ExterieurViewController.this.rimMap.get(new_toggle).getRimPriceInCent());
                }
            });
        }
    }

    public void fillCarMirrorBoxes(List<Mirror> mirrors) {
        this.toggleGroupMirror = new ToggleGroup();
        for (Mirror mirror : mirrors) {
            RadioButton radioButton = new RadioButton("Spiegelart: " + mirror.getMirrorShape() + " Preis: " + mirror.getMirrorPriceInCent());
            this.exterieurView.getMirrorBox().getChildren().addAll(radioButton);
            this.mirrorMap.put(radioButton, mirror);
            this.mirrorMapForDTOConversion.put(mirror.getMirrorId(), mirror);
            radioButton.setToggleGroup(this.toggleGroupMirror);
            this.toggleGroupMirror.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                @Override
                public void changed(ObservableValue<? extends Toggle> ov,
                                    Toggle old_toggle, Toggle new_toggle) {
                    ExterieurViewController.this.currentPriceMirror.set(ExterieurViewController.this.mirrorMap.get(new_toggle).getMirrorPriceInCent());
                }
            });
        }
    }

    public void fillCarPaintBoxes(List<CarPaint> carPaints) {
        this.toggleGroupCarPaint = new ToggleGroup();
        for (CarPaint carPaint : carPaints) {
            RadioButton carPaintRadioButton = new RadioButton("Farbe: " + carPaint.getCarPaintName() + " Preis: " + carPaint.getCarPaintPriceInCent());
            this.exterieurView.getCarpaintBox().getChildren().add(carPaintRadioButton);
            this.carPaintMap.put(carPaintRadioButton, carPaint);
            this.carPaintMapForDTOConversion.put(carPaint.getCarPaintId(), carPaint);

            carPaintRadioButton.setToggleGroup(this.toggleGroupCarPaint);
            this.toggleGroupCarPaint.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
                @Override
                public void changed(ObservableValue<? extends Toggle> ov,
                                    Toggle old_toggle, Toggle new_toggle) {

                    ExterieurViewController.this.currentPriceCarPaint.set(ExterieurViewController.this.carPaintMap.get(new_toggle).getCarPaintPriceInCent());
                }
            });
        }
    }

    public void takeSelectedRadiobuttonAndSetCorrespondingExterieurInIdBuzz() {
        RadioButton rbTyre = (RadioButton) this.toggleGroupTyre.getSelectedToggle();
        this.idbuzz.getExterieur().setTyre(this.tyreMap.get(rbTyre));
        RadioButton rbRim = (RadioButton) this.toggleGroupRim.getSelectedToggle();
        this.idbuzz.getExterieur().setRim(this.rimMap.get(rbRim));
        RadioButton rbMirror = (RadioButton) this.toggleGroupMirror.getSelectedToggle();
        this.idbuzz.getExterieur().setMirror(this.mirrorMap.get(rbMirror));
        RadioButton rbCarPaintcolor = (RadioButton) this.toggleGroupCarPaint.getSelectedToggle();
        this.idbuzz.getExterieur().setColor(this.carPaintMap.get(rbCarPaintcolor));
    }

    public List<Rim> getAllRims() {
        WebRequest<List<Rim>> webRequestList = new WebRequest<>("/rims");
        try {
            this.rimList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, Rim.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.rimList;
    }

    public List<Tyre> getAllTyres() {
        WebRequest<List<Tyre>> webRequestList = new WebRequest<>("/tyres");
        try {
            this.tyreList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, Tyre.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.tyreList;
    }

    public List<Mirror> getAllMirrors() {
        WebRequest<List<Mirror>> webRequestList = new WebRequest<>("/mirrors");
        try {
            this.mirrorlist.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, Mirror.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.mirrorlist;
    }

    public List<CarPaint> getAllCarPaints() {
        WebRequest<List<CarPaint>> webRequestList = new WebRequest<>("/carPaints");
        try {
            this.carpaintList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, CarPaint.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.carpaintList;
    }

}

package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
/**
 * @author Sarah Klein
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BuzzDTO {
    private long buzzConfigurationCode;
    private long carModel;
    private long engine;
    private long rim;
    private long tyre;
    private long mirror;
    private long carPaint;
    private long seat;
    private long steerWheel;
    private long trim;
    private List<Long> extras;
}

package de.buzz.frontend.controller;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import de.buzz.frontend.model.Extra;
import de.buzz.frontend.model.IdBuzz;
import de.buzz.frontend.view.FinishView;
import de.buzz.frontend.view.MainView;
import de.buzz.frontend.view.StartView;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
/**
 * @author Sarah Klein
 */
public class FinishViewController {
    private FinishView finishView;
    private MainView mainView;
    private IdBuzz idbuzz;

    public FinishViewController(FinishView finishView, MainView mainView, IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.finishView = finishView;
        this.mainView = mainView;
        handleExportTXtButton();
        handleExportPDFButton();
        handleExit();


    }


    private void handleExportPDFButton() {
        this.finishView.getExportPDFButton().setOnAction(e -> {
            Document document = new Document();

            try {
                PdfWriter.getInstance(document, new FileOutputStream("yourIdBuzz.pdf"));
                document.open();
                Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
                Chunk chunkModel = new Chunk("Modell: " + this.idbuzz.getModel().getCarModelName(), font);
                Chunk chunkEngine = new Chunk("Motor: " + this.idbuzz.getEngine().getEnginesSpecification(), font);
                Chunk chunkExterieur1 = new Chunk("Felge: " + this.idbuzz.getExterieur().getRim().getRimSpecification(), font);
                Chunk chunkExterieur3 = new Chunk("Reifen: " + this.idbuzz.getExterieur().getTyre().getTyreSpecification(), font);
                Chunk chunkExterieur2 = new Chunk("Farbe: " + this.idbuzz.getExterieur().getColor().getCarPaintName() + " ,Spiegel: " + this.idbuzz.getExterieur().getMirror().getMirrorShape(), font);
                Chunk chunkInterieur = new Chunk("Sitz: " + this.idbuzz.getInterieur().getSeat().getSeatColor(), font);
                Chunk chunkInterieur2 = new Chunk("Lenkrad: " + this.idbuzz.getInterieur().getSteeringwheel().getSteerWheelColor(), font);

                document.add(chunkModel);
                document.newPage();
                document.add(chunkEngine);
                document.newPage();
                document.add(chunkExterieur1);
                document.newPage();
                document.add(chunkExterieur3);
                document.newPage();
                document.add(chunkExterieur2);
                document.newPage();
                document.add(chunkInterieur);
                document.newPage();
                document.add(chunkInterieur2);
                document.newPage();
                for (Extra extra : this.idbuzz.getExtras()) {
                    Chunk chunkExtras = new Chunk("Extra: " + extra.getExtraName(), font);
                    document.add(chunkExtras);
                    document.newPage();

                }
                document.close();
            } catch (FileNotFoundException | DocumentException ex) {
                ex.printStackTrace();
            }


        });
    }

    public void handleExportTXtButton() {
        this.finishView.getExportTxtButton().setOnAction(e -> {

            String text = this.idbuzz.toString();

            String fileName = "YourIDBUZZ.txt";
            FileOutputStream writer =
                    null;
            try {
                writer = new FileOutputStream(fileName);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            for (int i = 0; i < text.length(); i++) {
                try {
                    writer.write((byte) text.charAt(i));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
            try {
                writer.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            System.out.println("Datei ist geschrieben!");


        });

    }

    public void handleExit() {
        this.finishView.getExitButton().setOnAction(e -> {
            StartView view = new StartView();
            StartViewController startViewController = new StartViewController(view);
            this.mainView.getScene().setRoot(view);
        });
    }
}




package de.buzz.frontend.controller;

import de.buzz.frontend.model.Extra;
import de.buzz.frontend.model.IdBuzz;
import de.buzz.frontend.view.ExtraView;
import de.buzz.frontend.view.MainView;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.scene.control.RadioButton;
import lombok.Data;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Sarah Klein
 */
@Data
public class ExtraViewController {
    private ExtraView extraView;
    private MainView mainView;
    private ObservableList<RadioButton> selectedRadioButtonsList = FXCollections.observableArrayList();
    private List<Extra> extrasList = new ArrayList<>();
    private Map<RadioButton, Extra> extrasMap = new HashMap<>();
    private Map<Long, Extra> extrasForDTOConversion = new HashMap<>();
    private IntegerProperty currentPriceExtra;
    private IdBuzz idbuzz;

    public ExtraViewController(ExtraView extraView, MainView mainView, IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.extraView = extraView;
        this.mainView = mainView;
        this.currentPriceExtra = new SimpleIntegerProperty(0);
        fillExtraBoxes(getAllExtras());
    }

    public void fillExtraBoxes(List<Extra> extras) {

        this.selectedRadioButtonsList.addListener(new ListChangeListener<RadioButton>() {
            @Override
            public void onChanged(Change<? extends RadioButton> c) {
                ExtraViewController.this.currentPriceExtra.set(ExtraViewController.this.selectedRadioButtonsList.stream().map(e -> ExtraViewController.this.extrasMap.get(e).getExtraPriceInCent()).reduce(0, Integer::sum));
            }
        });

        for (Extra extra : extras) {
            RadioButton radiobutton = new RadioButton(extra.getExtraName() + " Preis: " + extra.getExtraPriceInCent());
            radiobutton.setOnAction(e -> {
                if (radiobutton.isSelected()) {
                    this.selectedRadioButtonsList.add(radiobutton);
                } else if (!radiobutton.isSelected()) {
                    this.selectedRadioButtonsList.remove(radiobutton);
                }
            });

            this.extrasMap.put(radiobutton, extra);
            this.extrasForDTOConversion.put(extra.getExtraId(), extra);
            this.extraView.getExtraBox().getChildren().addAll(radiobutton);


        }
    }

    public void takeSelectedRadiobuttonAndSetCorrespondingExtraInIdBuzz() {
        for (RadioButton rb : this.selectedRadioButtonsList) {
            Extra extra = this.extrasMap.get(rb);
            this.idbuzz.getExtras().add(extra);
        }
    }

    public List<Extra> getAllExtras() {
        WebRequest<List<Extra>> webRequestList = new WebRequest<>("/extras");
        try {
            this.extrasList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, Extra.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.extrasList;
    }
}



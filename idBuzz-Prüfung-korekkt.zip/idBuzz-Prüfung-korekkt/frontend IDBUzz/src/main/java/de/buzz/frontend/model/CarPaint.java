package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CarPaint {
    private String carPaintName;
    private String carPaintPattern;
    private int carPaintPriceInCent;
    private long carPaintId;
}

package de.buzz.frontend.view;


import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */
@Data
public class ModelView extends BorderPane {
    private RadioButton idbuzzButton;
    private RadioButton idbuzzCargoButton;
    private RadioButton idbuzzeleganceButton;


    private VBox radioBox;
    private HBox bottomBox;
   
    private Label priceLabel;
    private Button button;

    public ModelView() {


        initializeCenter();
        setCenter(this.radioBox);

    }

    private void initializeCenter() {
        this.radioBox = new VBox();
        this.radioBox.setAlignment(Pos.CENTER);
    }


}

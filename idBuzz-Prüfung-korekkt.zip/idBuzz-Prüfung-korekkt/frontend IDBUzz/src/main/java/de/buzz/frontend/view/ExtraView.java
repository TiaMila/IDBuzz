package de.buzz.frontend.view;


import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */
@Data
public class ExtraView extends BorderPane {
    private Label extraLabel;
    private VBox extraBox;
    private Label priceLabel;
    private HBox bottomBox;
    private HBox topBox;


    public ExtraView() {
        initializeExtraView();
        this.setCenter(this.extraBox);
    }

    private void initializeExtraView() {
        this.extraLabel = new Label("extras");
        this.extraBox = new VBox();
        this.extraBox.getChildren().add(this.extraLabel);
        this.extraBox.setAlignment(Pos.CENTER);

    }

}

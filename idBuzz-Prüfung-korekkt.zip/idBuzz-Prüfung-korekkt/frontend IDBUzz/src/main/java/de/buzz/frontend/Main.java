package de.buzz.frontend;


import de.buzz.frontend.controller.StartViewController;
import de.buzz.frontend.view.StartView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
;
/**
 * @author Sarah Klein
 */
public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        try {
            StartView view = new StartView();
            StartViewController startViewController = new StartViewController(view);
            Scene scene = new Scene(startViewController.getView(), 800, 500);
            primaryStage.setScene(scene);
            primaryStage.setTitle("ID.Buzz-Konfigurator");
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }


}
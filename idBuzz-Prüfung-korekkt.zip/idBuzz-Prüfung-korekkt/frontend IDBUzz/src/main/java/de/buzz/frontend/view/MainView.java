package de.buzz.frontend.view;


import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */
@Data
public class MainView extends BorderPane {


    private HBox topBox;
    private Button backButton;
    private HBox bottomBox;
    private Button forewardButton;
    private Label priceLabel;
    private Label priceTextLabel;

    public MainView() {


        initializeBackButtonTop();
        initializeBottom();
        this.setTop(this.topBox);
        this.setBottom(this.bottomBox);


    }


    public void initializeBackButtonTop() {
        this.topBox = new HBox();
        this.backButton = new Button();
        this.backButton.setText("Zurück");
        this.topBox.getChildren().add(this.backButton);
    }


    private void initializeBottom() {
        this.bottomBox = new HBox();
        this.forewardButton = new Button();
        this.forewardButton.setText("Weiter");
        this.priceTextLabel = new Label("Preis in Cent:");
        this.priceLabel = new Label();
        this.bottomBox.getChildren().addAll(this.priceTextLabel, this.priceLabel, this.forewardButton);
        this.bottomBox.setAlignment(Pos.CENTER);
    }

  
}

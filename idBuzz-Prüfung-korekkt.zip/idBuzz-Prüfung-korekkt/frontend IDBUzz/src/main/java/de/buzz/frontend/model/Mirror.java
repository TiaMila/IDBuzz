package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Mirror {

    private boolean isCarPainting;
    private String mirrorShape;
    private int mirrorPriceInCent;
    private long mirrorId;
    private boolean isInCarPainting;

}

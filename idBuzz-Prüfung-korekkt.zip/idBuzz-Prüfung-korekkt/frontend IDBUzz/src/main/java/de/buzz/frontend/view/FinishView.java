package de.buzz.frontend.view;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */

@Data
public class FinishView extends BorderPane {
    private Label idLabel;
    private Label finishLabel;
    private Button exportTxtButton;
    private Button exportPDFButton;
    private Button exitButton;
    private VBox finishBox;


    public FinishView() {

        initializeFinishView();


        this.setCenter(this.finishBox);


    }


    private void initializeFinishView() {
        this.finishLabel = new Label("Danke für ihre Bestellung");
        this.idLabel = new Label();
        this.exportTxtButton = new Button("Export Txt");
        this.exportPDFButton = new Button("Export PDF");

        this.exitButton = new Button("Exit");
        this.idLabel.setText("Ihre ID lautet : id");
        this.finishBox = new VBox();
        this.finishBox.getChildren().addAll(this.finishLabel, this.idLabel, this.exportTxtButton, this.exportPDFButton, this.exitButton);
        this.finishBox.setAlignment(Pos.CENTER);

    }


}

package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.List;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class IdBuzz {
    private long configurationID;
    private CarModel model;
    private Exterieur exterieur;
    private Interieur interieur;
    private Engine engine;
    private List<Extra> extras;
}

package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CarModel {
    private String carModelName;
    private int carModelPriceInCent;
    private long carModelId;


}

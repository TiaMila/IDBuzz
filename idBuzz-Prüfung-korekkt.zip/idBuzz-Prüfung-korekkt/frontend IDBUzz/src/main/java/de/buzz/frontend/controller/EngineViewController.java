package de.buzz.frontend.controller;

import de.buzz.frontend.model.Engine;
import de.buzz.frontend.model.IdBuzz;
import de.buzz.frontend.view.EngineView;
import de.buzz.frontend.view.ExterieurView;
import de.buzz.frontend.view.MainView;
import de.buzz.frontend.webRequest.WebRequest;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import lombok.Data;


import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Sarah Klein
 */
@Data
public class EngineViewController {
    private EngineView engineView;
    private MainView mainView;
    private ExterieurView exterieurView;
    private List<Engine> engineList = new ArrayList<>();
    private ToggleGroup toggleGroup;
    private Map<RadioButton, Engine> engineMap = new HashMap<>();
    private Map<Long, Engine> engineMapForDTOConversion = new HashMap<>();
    private IntegerProperty currentPrice;
    private IdBuzz idbuzz;

    public EngineViewController(EngineView engineView, MainView mainView, ExterieurView exterieurView, IdBuzz idbuzz) {
        this.idbuzz = idbuzz;
        this.engineView = engineView;
        this.mainView = mainView;
        this.exterieurView = exterieurView;
        this.currentPrice = new SimpleIntegerProperty(0);
        fillEngineBoxes(getAllEngines());
    }

    public void changeCenterWhenToggleIsSelected() {
        if (this.toggleGroup.getSelectedToggle() == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Option treffen");
            alert.setContentText("es muss eine Option angewählt sein");
            alert.showAndWait();
        } else {
            this.mainView.setCenter(this.exterieurView);
            takeSelectedRadiobuttonAndSetCorrespondingEngineInIdBuzz();
        }

    }

    public void fillEngineBoxes(List<Engine> engines) {
        this.toggleGroup = new ToggleGroup();
        for (Engine engine : engines) {
            RadioButton radioButton = new RadioButton("Motor: " + engine.getEnginesSpecification() + " Preis: " + engine.getEnginePriceInCent());
            this.engineView.getEngineBox().setAlignment(Pos.CENTER);
            this.engineView.getEngineBox().getChildren().addAll(radioButton, new Label("Reichweite: " + String.valueOf(engine.getMaxReachInKM())));
            this.engineMap.put(radioButton, engine);
            this.engineMapForDTOConversion.put(engine.getEngineId(), engine);
            addToggleGroupChangeListener(radioButton, this.toggleGroup);
        }
    }

    private void addToggleGroupChangeListener(RadioButton radioButton, ToggleGroup toggleGroup) {
        radioButton.setToggleGroup(toggleGroup);
        toggleGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
            @Override
            public void changed(ObservableValue<? extends Toggle> ov,
                                Toggle old_toggle, Toggle new_toggle) {
                EngineViewController.this.currentPrice.set(EngineViewController.this.engineMap.get(new_toggle).getEnginePriceInCent());
            }
        });
    }


    public void takeSelectedRadiobuttonAndSetCorrespondingEngineInIdBuzz() {
        RadioButton rb = (RadioButton) this.toggleGroup.getSelectedToggle();
        this.idbuzz.setEngine(this.engineMap.get(rb));
    }


    public List<Engine> getAllEngines() {
        WebRequest<List<Engine>> webRequestList = new WebRequest<>("/engines");
        try {
            this.engineList.addAll(webRequestList.doRequestWithCollectionResponse("", WebRequest.RequestType.GET, Engine.class));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return this.engineList;

    }

}
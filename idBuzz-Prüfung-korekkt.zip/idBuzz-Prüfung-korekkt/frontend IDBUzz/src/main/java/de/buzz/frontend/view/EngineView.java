package de.buzz.frontend.view;

import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */
@Data
public class EngineView extends BorderPane {
    private VBox renderBox;
    private VBox engineBox;
    private int price;

    public EngineView() {
        initializeView();
        this.setCenter(this.renderBox);
    }


    private void initializeView() {
        this.engineBox = new VBox();
        this.renderBox = new VBox();
        this.renderBox.getChildren().add(this.engineBox);
        this.renderBox.setAlignment(Pos.CENTER);
    }


}

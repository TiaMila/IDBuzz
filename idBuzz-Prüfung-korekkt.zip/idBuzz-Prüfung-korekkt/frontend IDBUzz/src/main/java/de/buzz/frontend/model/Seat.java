package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Seat {
    private String seatPattern;
    private String seatColor;
    private String seatMaterial;
    private int seatPriceInCent;
    private long seatId;

}

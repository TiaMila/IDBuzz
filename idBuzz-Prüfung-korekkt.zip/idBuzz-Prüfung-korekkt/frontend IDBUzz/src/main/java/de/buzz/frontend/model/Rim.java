package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Rim {
    private String rimSpecification;
    private int rimPriceInCent;
    private long rimId;
    private String rimRestriction;

}

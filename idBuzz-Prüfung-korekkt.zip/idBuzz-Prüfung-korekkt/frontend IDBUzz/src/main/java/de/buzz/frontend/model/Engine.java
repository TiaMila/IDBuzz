package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Engine {
    private String enginesSpecification;
    private int maxReachInKM;
    private String outInHpAndKW;
    private int enginePriceInCent;
    private long engineId;

}

package de.buzz.frontend.webRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.java.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * @author Sarah Klein
 */
@Log
public class WebRequest<T> {

    private String domainExtension;
    private final String domain = "http://localhost:8090";
    private HttpURLConnection con;
    private ObjectMapper mapper;

    public WebRequest(String domainExtension) {
        this.domainExtension = domainExtension;
        this.mapper = new ObjectMapper();
        this.mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public T doRequest(String requestBody, RequestType requestType) throws IOException {
        return doRequest(requestBody, requestType, "");
    }

    public T doRequest(T requestBody, RequestType requestType, String optionalDomainExtension) throws IOException {
        return doRequest(objToJson(requestBody), requestType, optionalDomainExtension);
    }


    public T doRequest(T requestBody, RequestType requestType) throws IOException {
        return doRequest(objToJson(requestBody), requestType, "");
    }


    public <R> R doRequest(T requestBody, RequestType requestType, Class<R> responseType) throws IOException {
        return doRequest(objToJson(requestBody), requestType, responseType, "");
    }


    public <R> R doRequest(String requestBody, RequestType requestType, Class<R> responseType, String optionalDomainExtension) throws IOException {
        return this.mapper.readValue(doRequestInternal(requestBody, requestType, optionalDomainExtension), responseType);
    }


    public T doRequest(String requestBody, RequestType requestType, String optionalDomainExtension) throws IOException {
        return this.mapper.readValue(doRequestInternal(requestBody, requestType, optionalDomainExtension), new TypeReference<T>() {
        });
    }

    private String doRequestInternal(String requestBody, RequestType requestType, String optionalDomainExtension) throws IOException {
        try {
            URL url = new URL(this.domain + this.domainExtension + optionalDomainExtension);
            this.con = (HttpURLConnection) url.openConnection();
            this.con.setRequestMethod(requestType.getRequestType());

            if (requestType == RequestType.POST) {
                this.con.setDoOutput(true);
                this.con.setRequestProperty("Accept", "application/json");
                this.con.setRequestProperty("Content-Type", "application/json");
                String data = requestBody.toString();
                OutputStream stream = this.con.getOutputStream();
                stream.write(data.getBytes(StandardCharsets.UTF_8));
            }

            if (requestType == RequestType.PUT) {
                this.con.setDoOutput(true);
                this.con.setRequestMethod("PUT");
                this.con.setRequestProperty("Content-Type", "application/json");
                String data = requestBody.toString();
                OutputStream stream = this.con.getOutputStream();
                stream.write(data.getBytes(StandardCharsets.UTF_8));
            }

            if (requestType == RequestType.DELETE) {
                this.con.setDoOutput(true);
                this.con.setRequestMethod("DELETE");
                this.con.setRequestProperty("Accept", "application/json");
                String data = requestBody.toString();
                OutputStream stream = this.con.getOutputStream();
                stream.write(data.getBytes(StandardCharsets.UTF_8));
            }

            this.con.getResponseCode();
            StringBuilder content;
            if (requestType != RequestType.PUT) {
                try (BufferedReader in = new BufferedReader(new InputStreamReader(this.con.getInputStream()))) {

                    String line;
                    content = new StringBuilder();

                    while ((line = in.readLine()) != null) {

                        content.append(line);
                        content.append(System.lineSeparator());
                    }
                }
                return content.toString();
            } else {

                return "{}";
            }
        } finally {
            this.con.disconnect();
        }
    }

    public <T> List<T> doRequestWithCollectionResponse(String requestBody, RequestType requestType, Class<T> responseType, String optionalDomainExtension) throws IOException {
        return this.mapper.readValue(doRequestInternal(requestBody, requestType, optionalDomainExtension),
                this.mapper.getTypeFactory().constructCollectionType(List.class, responseType));
    }

    public <T> List<T> doRequestWithCollectionResponse(String requestBody, RequestType requestType, Class<T> responseType) throws IOException {
        return this.doRequestWithCollectionResponse(requestBody, requestType, responseType, "");
    }

    public T doRequest(String requestBody, RequestType requestType, Class<T> responseType) throws IOException {
        return this.mapper.readValue(doRequestInternal(requestBody, requestType, ""), responseType);
    }

    public T doRequest(String requestBody, RequestType requestType, String optionalDomainExtension, Class<T> clazz) throws IOException {
        return this.mapper.readValue(doRequestInternal(requestBody, requestType, optionalDomainExtension), clazz);
    }

    private String objToJson(T t) throws JsonProcessingException {
        return this.mapper.writeValueAsString(t);
    }


    public enum RequestType {
        PUT("PUT"), GET("GET"), POST("POST"), DELETE("DELETE");

        private String request;

        private RequestType(String request) {
            this.request = request;
        }

        public String getRequestType() {
            return this.request;
        }
    }
}
package de.buzz.frontend.view;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */
@Data
public class ExterieurView extends BorderPane {


    private Label rimLabel;
    private VBox rimBox;
    private HBox colorBox;
    private Label colorLabel;
    private VBox renderBox;
    private HBox wholeBox;
    private Label tyreLabel;
    private VBox tyreBox;
    private Label mirrorLabel;
    private VBox mirrorBox;

    private int priceExterieurView;
    private int currentPrice;
    private VBox carpaintBox;


    public ExterieurView() {

        initializeTopCenterView();

        initializeCenterView();
        initializeCenterBottomView();
        initializeLeft();
        initializeWholeCenter();
        this.setLeft(this.colorBox);
        this.setCenter(this.wholeBox);


    }

    private void initializeLeft() {
        this.colorBox = new HBox();
        this.colorBox.setAlignment(Pos.CENTER);
        this.setPadding(new Insets(5, 5, 5, 5));
        this.carpaintBox = new VBox();
        this.carpaintBox.setAlignment(Pos.CENTER);
        this.colorLabel = new Label();
        this.colorBox.getChildren().addAll(this.colorLabel, this.carpaintBox);
        this.colorBox.setAlignment(Pos.CENTER);
    }

    private void initializeTopCenterView() {
        this.rimLabel = new Label("Felgen");


        this.rimBox = new VBox();
        this.renderBox = new VBox();


        this.rimBox.setAlignment(Pos.CENTER_LEFT);
        this.renderBox.getChildren().addAll(this.rimLabel, this.rimBox);
        this.renderBox.setAlignment(Pos.CENTER_LEFT);
        this.rimBox.setPadding(new Insets(5, 25, 5, 5));
    }

    private void initializeCenterView() {
        this.tyreBox = new VBox();
        this.tyreLabel = new Label("Reifen");
        this.tyreBox.getChildren().add(this.tyreLabel);
        this.tyreBox.setAlignment(Pos.CENTER);
        this.tyreBox.setPadding(new Insets(5, 25, 5, 25));
    }

    private void initializeCenterBottomView() {
        this.mirrorLabel = new Label("Spiegel");
        this.mirrorBox = new VBox();
        this.mirrorBox.getChildren().add(this.mirrorLabel);
        this.mirrorBox.setAlignment(Pos.CENTER_RIGHT);
        this.mirrorBox.setPadding(new Insets(5, 5, 5, 25));

    }

    public void initializeWholeCenter() {
        this.wholeBox = new HBox();
        this.wholeBox.getChildren().addAll(this.renderBox, this.tyreBox, this.mirrorBox);
        this.wholeBox.setAlignment(Pos.CENTER);
    }


}

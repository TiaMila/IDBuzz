package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Exterieur {
    private CarPaint color;
    private Rim rim;
    private Tyre tyre;
    private Mirror mirror;


}

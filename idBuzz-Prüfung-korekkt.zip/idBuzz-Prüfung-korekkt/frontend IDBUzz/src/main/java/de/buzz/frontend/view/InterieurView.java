package de.buzz.frontend.view;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import lombok.Data;
/**
 * @author Sarah Klein
 */
@Data
public class InterieurView extends BorderPane {
    private Label seatLabel;

    private VBox seatBox;
    private HBox wholeBox;
    private Label steeringwheelLabel;

    private VBox steeringwheelBox;


    public InterieurView() {
        initializeSeatView();
        initialzeSteeringwheelView();
        initializeWholeCenter();
        this.setCenter(this.wholeBox);


    }


    private void initializeSeatView() {
        this.seatLabel = new Label("sitz");

        this.seatBox = new VBox();
        this.seatBox.getChildren().addAll(this.seatLabel);
        this.seatBox.setAlignment(Pos.CENTER_LEFT);


    }

    public void initialzeSteeringwheelView() {
        this.steeringwheelLabel = new Label("lenkrad");
        this.steeringwheelBox = new VBox(this.steeringwheelLabel);
        this.steeringwheelBox.setAlignment(Pos.CENTER_LEFT);
        this.steeringwheelBox.setPadding(new Insets(5, 25, 5, 5));


    }

    public void initializeWholeCenter() {
        this.wholeBox = new HBox();
        this.wholeBox.getChildren().addAll(this.seatBox, this.steeringwheelBox);
        this.wholeBox.setAlignment(Pos.CENTER);
    }


}

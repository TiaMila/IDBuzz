package de.buzz.frontend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author Sarah Klein
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Extra {
    private String extraName;
    private int extraPriceInCent;
    private long extraId;
}

package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class RimController {
    @Autowired
    RimService rimService;

    @GetMapping("/rims")
    public List<Rim> getAllRims() {
        List<Rim> rims = this.rimService.getAllRims();
        return rims;
    }

    @PostMapping("/rims")
    Rim newRim(@RequestBody Rim newRim) {

        return this.rimService.save(newRim);
    }
}

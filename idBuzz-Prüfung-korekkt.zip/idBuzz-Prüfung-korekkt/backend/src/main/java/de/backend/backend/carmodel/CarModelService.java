package de.backend.backend.carmodel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarModelService {
    @Autowired
    CarModelRepo carModelRepo;

    public List<CarModel> getAllCarModels() {
        return this.carModelRepo.findAll();

    }

    public CarModel save(CarModel newCarModel) {
        return this.carModelRepo.save(newCarModel);
    }
}


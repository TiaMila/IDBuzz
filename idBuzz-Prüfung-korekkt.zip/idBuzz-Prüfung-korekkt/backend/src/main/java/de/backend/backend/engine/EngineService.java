package de.backend.backend.engine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EngineService {

    @Autowired
    EngineRepo engineRepo;

    public List<Engine> getAllEngines() {
        return this.engineRepo.findAll();

    }

    public Engine save(Engine newEngine) {
        return this.engineRepo.save(newEngine);
    }
}

package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RimService {
    @Autowired
    RimRepo rimRepo;

    public List<Rim> getAllRims() {
        return this.rimRepo.findAll();

    }

    public Rim save(Rim newRim) {
        return this.rimRepo.save(newRim);
    }
}

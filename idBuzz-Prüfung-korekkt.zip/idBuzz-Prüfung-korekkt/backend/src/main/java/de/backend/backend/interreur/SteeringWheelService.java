package de.backend.backend.interreur;

import de.backend.backend.interreur.SteeringWheel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SteeringWheelService {
    @Autowired
    SteeringWheelRepo steeringWheelRepo;

    public List<SteeringWheel> getAllSteeringWheels() {
        return this.steeringWheelRepo.findAll();

    }

    public SteeringWheel save(SteeringWheel newSteeringWheels) {
        return this.steeringWheelRepo.save(newSteeringWheels);
    }
}

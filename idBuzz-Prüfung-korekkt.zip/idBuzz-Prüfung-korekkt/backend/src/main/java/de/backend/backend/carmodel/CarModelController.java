package de.backend.backend.carmodel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class CarModelController {
    @Autowired
    CarModelService carModelService;

    @GetMapping("/carModels")
    public List<CarModel> getAllCarModels() {
        List<CarModel> carModels = this.carModelService.getAllCarModels();
        return carModels;
    }

    @PostMapping("/carModels")
    CarModel newCarModel(@RequestBody CarModel newCarModel) {
        return this.carModelService.save(newCarModel);
    }
}

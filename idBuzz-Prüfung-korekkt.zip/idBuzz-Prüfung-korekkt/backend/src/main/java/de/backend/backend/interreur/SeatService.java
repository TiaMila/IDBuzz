package de.backend.backend.interreur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SeatService {
    @Autowired
    SeatRepo seatRepo;

    public List<Seat> getAllSeats() {
        return this.seatRepo.findAll();

    }

    public Seat save(Seat newSeats) {
        return this.seatRepo.save(newSeats);
    }
}

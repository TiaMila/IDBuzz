package de.backend.backend.idBuzz;

import de.backend.backend.carmodel.CarModel;
import de.backend.backend.engine.Engine;
import de.backend.backend.exterieur.CarPaint;
import de.backend.backend.exterieur.Mirror;
import de.backend.backend.exterieur.Rim;
import de.backend.backend.exterieur.Tyre;
import de.backend.backend.interreur.Seat;
import de.backend.backend.interreur.SteeringWheel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;


@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IdBuzz {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int configurationID;

    @ManyToOne
    @JoinColumn(name = "model_car_model_id")
    private CarModel model;
    @ManyToOne
    @JoinColumn(name = "engine_engine_id")
    private Engine engine;
    @ManyToOne
    @JoinColumn(name = "car_paint_car_paint_id")
    private CarPaint carPaint;
    @ManyToOne
    @JoinColumn(name = "mirror_mirror_id")
    private Mirror mirror;
    @ManyToOne
    @JoinColumn(name = "rim_rim_id")
    private Rim rim;
    @ManyToOne
    @JoinColumn(name = "tyre_tyre_id")
    private Tyre tyre;
    @ManyToOne
    @JoinColumn(name = "seat_seat_id")
    private Seat seat;
    @ManyToOne
    @JoinColumn(name = "steering_wheel_steering_wheel_id")
    private SteeringWheel steeringWheel;

    private int Price;


}

package de.backend.backend.exterieur;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.Optional;

@Repository
@CrossOrigin("*")
public interface TyreRepo extends JpaRepository<Tyre, Long> {
    @Override
    Optional<Tyre> findById(Long aLong);
}

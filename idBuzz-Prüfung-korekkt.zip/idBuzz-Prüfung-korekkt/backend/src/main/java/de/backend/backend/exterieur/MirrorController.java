package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class MirrorController {
    @Autowired
    MirrorService mirrorService;

    @GetMapping("/mirrors")
    public List<Mirror> getAllMirrors() {
        List<Mirror> mirrors = this.mirrorService.getAllMirrors();
        return mirrors;
    }


    @PostMapping("/mirrors")
    Mirror newMirrors(@RequestBody Mirror newMirrors) {

        return this.mirrorService.save(newMirrors);
    }
}

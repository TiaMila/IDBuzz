package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TyreService {
    @Autowired
    TyreRepo tyreRepo;

    public List<Tyre> getAllTyres() {
        return this.tyreRepo.findAll();

    }

    public Tyre save(Tyre newTyre) {
        return this.tyreRepo.save(newTyre);
    }
}

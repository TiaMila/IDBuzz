package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class CarPaintController {
    @Autowired
    CarpaintService carpaintService;

    @GetMapping("/carPaints")
    public List<CarPaint> getAllCarPaints() {
        List<CarPaint> carPaints = this.carpaintService.getAllCarPaints();
        return carPaints;
    }

    @PostMapping("/carPaints")
    CarPaint newCarPaints(@RequestBody CarPaint newCarPaints) {
        return this.carpaintService.save(newCarPaints);
    }
}

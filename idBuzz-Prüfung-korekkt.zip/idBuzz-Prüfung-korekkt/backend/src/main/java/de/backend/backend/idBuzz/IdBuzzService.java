package de.backend.backend.idBuzz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IdBuzzService {

    @Autowired
    IdBuzzRepo idBuzzRepo;

    public List<IdBuzz> getAllIdBuzzs() {
        return this.idBuzzRepo.findAll();

    }

    public IdBuzz save(IdBuzz newIdBuzz) {
        return this.idBuzzRepo.save(newIdBuzz);
    }
}

package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class TyreController {
    @Autowired
    TyreService tyreService;

    @GetMapping("/tyres")
    public List<Tyre> getAllTyres() {
        List<Tyre> tyres = this.tyreService.getAllTyres();
        return tyres;
    }

    @PostMapping("/tyres")
    Tyre newTyre(@RequestBody Tyre newTyre) {

        return this.tyreService.save(newTyre);
    }
}

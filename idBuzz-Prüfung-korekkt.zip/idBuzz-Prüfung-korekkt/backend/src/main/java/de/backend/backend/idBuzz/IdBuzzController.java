package de.backend.backend.idBuzz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class IdBuzzController {
    @Autowired
    IdBuzzService idBuzzService;

    @GetMapping("/idbuzzs")
    public List<IdBuzz> getAllIdBuzzs() {
        List<IdBuzz> idBuzzs = this.idBuzzService.getAllIdBuzzs();
        return idBuzzs;
    }

    @PostMapping("/idbuzzs")
    IdBuzz newIdBuzz(@RequestBody IdBuzz newIdBuzz) {

        return this.idBuzzService.save(newIdBuzz);
    }
}

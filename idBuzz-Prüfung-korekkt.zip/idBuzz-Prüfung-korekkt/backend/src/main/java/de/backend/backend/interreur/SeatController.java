package de.backend.backend.interreur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class SeatController {
    @Autowired
    SeatService seatService;

    @GetMapping("/seats")
    public List<Seat> getAllSeats() {
        List<Seat> seats = this.seatService.getAllSeats();
        return seats;
    }

    @PostMapping("/seats")
    Seat newSeats(@RequestBody Seat newSeats) {

        return this.seatService.save(newSeats);
    }
}

package de.backend.backend.exterieur;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Exterieur {

    private CarPaint color;
    private Rim rim;
    private Tyre tyre;
    private Mirror mirror;


}

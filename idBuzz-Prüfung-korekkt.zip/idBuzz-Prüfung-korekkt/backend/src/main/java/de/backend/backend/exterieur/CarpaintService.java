package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarpaintService {
    @Autowired
    CarPaintRepo carPaintRepo;

    public List<CarPaint> getAllCarPaints() {
        return this.carPaintRepo.findAll();

    }

    public CarPaint save(CarPaint newCarPaints) {
        return this.carPaintRepo.save(newCarPaints);
    }
}

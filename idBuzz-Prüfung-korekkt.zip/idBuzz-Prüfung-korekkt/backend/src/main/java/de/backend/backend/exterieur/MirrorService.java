package de.backend.backend.exterieur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MirrorService {

    @Autowired
    MirrorRepo mirrorRepo;

    public List<Mirror> getAllMirrors() {
        return this.mirrorRepo.findAll();

    }

    public Mirror save(Mirror newMirrors) {
    
        return this.mirrorRepo.save(newMirrors);
    }
}

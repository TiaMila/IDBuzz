package de.backend.backend.engine;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class EngineController {
    @Autowired
    EngineService engineService;

    @GetMapping("/engines")
    public List<Engine> getAllEngines() {
        List<Engine> engines = this.engineService.getAllEngines();
        return engines;
    }

    @PostMapping("/engines")
    Engine newEngine(@RequestBody Engine newEngine) {
        return this.engineService.save(newEngine);
    }
}

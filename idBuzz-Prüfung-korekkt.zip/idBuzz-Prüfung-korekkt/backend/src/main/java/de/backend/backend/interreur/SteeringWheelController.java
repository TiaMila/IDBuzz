package de.backend.backend.interreur;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class SteeringWheelController {
    @Autowired
    SteeringWheelService steeringWheelService;

    @GetMapping("/steeringWheels")
    public List<SteeringWheel> getAllSteeringWheels() {
        return this.steeringWheelService.getAllSteeringWheels();
    }

    @PostMapping("/steeringWheels")
    SteeringWheel newSteeringWheels(@RequestBody SteeringWheel newSteeringWheel) {
        return this.steeringWheelService.save(newSteeringWheel);
    }
}
